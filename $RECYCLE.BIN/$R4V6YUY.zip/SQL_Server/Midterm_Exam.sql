
--1.Cau 1
CREATE Or Alter PROCEDURE sp_ThongTinDocGia  as 
BEGIN
    DECLARE @ngaysinh int 
    SELECT  @ngaysinh = DateDiff(year,Convert([datetime],NgaySinh,110),year(GetDate()))
    from DocGia 
    if(@ngaysinh > 18 )
        BEGIN
            SELECT * 
            From NguoiLon join DocGia on DocGia.MaDocGia = NguoiLon.MaDocGia
        END
    Else 
        BEGIN
            Select * 
            From TreEm join DocGia on DocGia.MaDocGia = TreEm.MaDocGia
        End
   
END
Exec sp_ThongTinDocGia 
Go
--Cau 2 
Create or alter procedure sp_ThongTinNguoiLonDangMuon as
BEGIN
    SELECT DocGia.MaDocGia,Ho, TenLot,Ten,NgaySinh
    From DocGia join NguoiLon on DocGia.MaDocGia = NguoiLon.MaDocGia
        join Muon on NguoiLon.MaDocGia = Muon.Ma_DocGia
         
END
EXEC sp_ThongTinNguoiLonDangMuon
Go
--cau 3
Create  or alter Procedure sp_CapnhatTrangthaiDausach
@isbn int
AS
Begin transaction
	Begin try
		if @isbn=null 
	Begin 
		print 'Thong tin nhap rong'
		rollback transaction
		return
	End
	if NOT EXISTS (Select *
					From [DauSach ]
					Where ISBN = @isbn)
	Begin 
		print 'Ma dau sach khong ton tai'
		rollback transaction
		return
	 End
	End try
	 Begin catch 
			--bao loi
			print '1- Cap Nhat khong thanh cong'
			rollback transaction
	End catch
		if NOT EXISTS ( Select * from CuonSach where isbn = @isbn AND TinhTrang = 'Y')
		Begin
			Update [DauSach]
			Set [DauSach].TrangThai = 'N' 
			Where ([DauSach].ISBN = @isbn)
		End
		Else if EXISTS ( Select * from CuonSach where isbn = @isbn AND TinhTrang = 'Y')
		Begin
			Update [DauSach]
			Set [DauSach].TrangThai = 'Y' 
			Where ([DauSach].ISBN = @isbn) 	
		End
		print '0-Cap Nhat thanh cong';
		commit transaction
exec sp_CapnhatTrangthaiDausach '15'
go 
--cau5 
Create proc sp_ThemNguoilon
@ho nvarchar(20),
@tenlot nvarchar(20),
@ten nvarchar(20),
@NgaySinh datetime,
@sonha nvarchar(20),
@duong nvarchar(63),
@quan nvarchar(20),
@dienthoai nvarchar(255)
AS
Begin transaction
Declare 
@ma smallint,
@han_sd smalldatetime;
Begin try
	if ( @ho=null or @ten=null or @NgaySinh=null or @sonha = null or @duong =null or @quan=null)
	Begin 
		print 'Empty'
		rollback transaction
		return
	End
	if (datediff (YY,@NgaySinh,getdate()) <=18)
	Begin 
		print 'Not Enough'
		rollback transaction
		return
	End
End try
Begin catch
			
			print ' Cannot add'
			rollback transaction
End catch
set @ma=1;
while (exists (select * from DocGia where MaDocGia=@ma)) 
set @ma=@ma+1;
set @han_sd = DATEADD (MM,6,GETDATE()) ;
Insert into DocGia values (@ma,@ho,@tenlot,@ten,@ngaysinh); 
Insert into NguoiLon values (@ma,@sonha,@duong,@quan,@dienthoai,@han_sd); 
commit transaction
Go
 EXECUTE sp_ThemNguoilon 'Mai Ngoc','Anh','Duy','09/06/1999','123','Melbourne','2','123456789123'
 go
 --cau6
Create proc sp_XoaDocGia 
@ma_doc_gia int 
AS
Begin transaction
Begin try
if (@ma_doc_gia = null)
Begin 
		print 'Thong tin nhap trong'
		rollback transaction
		return
End
if NOT EXISTS (Select * from DocGia where @ma_doc_gia = MaDocGia)
Begin 
		print 'Ma doc gia khong ton tai'
		rollback transaction
		return
End
if EXISTS ( Select * from Muon where @ma_doc_gia = Ma_DocGia )
Begin 
		print 'Doc gia dang muon sach khong the xoa'
		rollback transaction
		return
End
End try
Begin catch
			--bao loi
			print '1- Xoa khong thanh cong'
			rollback transaction
End catch
if exists (select * from NguoiLon where MaDocGia=@ma_doc_gia)
begin 
	if not exists (select * from TreEm where @ma_doc_gia= MaDocGia_NguoiLon )
	begin 
		delete from NguoiLon where MaDocGia=@ma_doc_gia;
		delete from QuaTrinhMuon where Ma_DocGia= @ma_doc_gia;
		delete from Muon where Ma_DocGia= @ma_doc_gia;
		delete from DangKy where MaDocGia= @ma_doc_gia;
	end
	else 
	begin 
		if exists ( select * from Muon m, TreEm te where te.MaDocGia_NguoiLon = @ma_doc_gia AND te.MaDocGia = m.ma_docgia)
		begin
			raiserror ('doc gia nay co tre em dang muon sach',18,1);
		end
		else 
		begin
			delete from TreEm where MaDocGia_NguoiLon = @ma_doc_gia;
			delete from NguoiLon where MaDocGia=@ma_doc_gia;
			delete from QuaTrinhMuon where Ma_DocGia= @ma_doc_gia;
			delete from Muon where Ma_DocGia= @ma_doc_gia;
			delete from DangKy where MaDocGia= @ma_doc_gia;
		end
	end
end
else if exists (select * from TreEm where MaDocGia=@ma_doc_gia)
begin
			delete from TreEm where MaDocGia = @ma_doc_gia;
			delete from QuaTrinhMuon where Ma_DocGia= @ma_doc_gia;
			delete from Muon where Ma_DocGia= @ma_doc_gia;
			delete from DangKy where MaDocGia= @ma_doc_gia;
end
Alter table TreEm
	Drop constraint TreEm_DocGia
Alter table NguoiLon 
	Drop constraint NguoiLon_DocGia 
Delete from DocGia where MaDocGia=@ma_doc_gia;
Alter table TreEm 
	Add constraint TreEm_DocGia foreign key(MaDocGia) references  DocGia(MaDocGia)
Alter table NguoiLon 
	Add constraint NguoiLon_DocGia foreign key(MaDocGia) references  DocGia(MaDocGia)
commit transaction
Go
EXEC sp_XoaDocGia '1'


--cau 8.Triggerfunction 
 CREATE TRIGGER tg_delMuon  ON Muon
 FOR delete
 AS
 Begin
 DECLARE @isbn int, 
 @Ma_CuonSach smallint
 SELECT @isbn = isbn, @Ma_CuonSach = ma_cuonsach
 FROM deleted
 
 UPDATE CuonSach
 SET TinhTrang='Y'
 WHERE isbn = @isbn 
 AND Ma_CuonSach = @ma_cuonsach
 End

 Go

			
